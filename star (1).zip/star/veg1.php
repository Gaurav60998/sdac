<?php
include('config.php');

// Fetch products from the database
$sql = "SELECT id, name, price, description, FROM products";
$result = mysqli_query($conn, $sql);

// Check if there are any products
if (mysqli_num_rows($result) > 0) {
    // Output data of each row
    while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <div class="col-lg-6">
            <div class="d-flex align-items-center">
                <div class="w-100 d-flex flex-column text-start ps-4">
                    <h5 class="d-flex justify-content-between border-bottom pb-2">
                        <span><?php echo $row['name']; ?></span>
                        <span class="text-primary">$<?php echo $row['price']; ?></span>
                    </h5>
                    <small class="fst-italic"><?php echo $row['description']; ?></small>
                </div>
            </div>
        </div>
        <?php
    }
} else {
    echo "No products found.";
}

// Close the database connection
mysqli_close($conn);
?>