<?php 

include('config.php');

$name=$_POST["name"];
$email=$_POST["email"];
$address=$_POST["address"];
$pass=$_POST["pass"];


$sql = "INSERT INTO `users` (`id`, `name`, `email`, `password`, `address`) VALUES (Null, '$name', '$email', '$pass', '$address');";

if (mysqli_query($conn,$sql)) {
    header("Location: login.html");
} else {
    echo "something went wrong".mysqli_error($conn);
}


mysqli_close($conn);

?>